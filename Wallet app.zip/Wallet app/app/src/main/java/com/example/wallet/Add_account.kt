package com.example.wallet

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Add_account : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_account)
    }
}