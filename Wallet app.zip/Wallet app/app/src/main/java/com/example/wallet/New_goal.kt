package com.example.wallet

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class New_goal : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_new_goal)
    }
}