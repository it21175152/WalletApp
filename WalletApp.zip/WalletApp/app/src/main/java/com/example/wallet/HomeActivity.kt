package com.example.wallet

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView

class HomeActivity : AppCompatActivity() {

    private lateinit var budgetRec: ImageView
    private lateinit var debtsRec: ImageView
    private lateinit var goalsRec: ImageView
    private lateinit var shoppingListRec: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        budgetRec = findViewById(R.id.budgetRec)
        debtsRec = findViewById(R.id.debtsRec)
        goalsRec = findViewById(R.id.goalsRec)
        shoppingListRec = findViewById(R.id.shoppingListRec)

        budgetRec.setOnClickListener {
            val intent = Intent(this, GoalDetailsActivity::class.java)
            startActivity(intent)
        }

        debtsRec.setOnClickListener {
            val intent = Intent(this, EditGoalActivity::class.java)
            startActivity(intent)
        }

        goalsRec.setOnClickListener {
            val intent = Intent(this, DisplayGoalsActivity::class.java)
            startActivity(intent)
        }

        shoppingListRec.setOnClickListener {
            val intent = Intent(this, DisplayGoalsActivity::class.java)
            startActivity(intent)
        }

    }
}