package com.example.models

data class GoalModel(
    var goalId: String? = null,
    var goalName: String? = null,
    var goalAmount: String? = null,
    var goalSaved: String? = null,
    var goalDate: String? = null,
    var goalNote: String? = null,
)
