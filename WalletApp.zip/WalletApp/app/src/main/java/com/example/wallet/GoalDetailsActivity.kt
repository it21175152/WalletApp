package com.example.wallet

import android.content.Intent
import android.icu.util.CurrencyAmount
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.example.models.GoalModel
import com.google.firebase.database.FirebaseDatabase

class GoalDetailsActivity : AppCompatActivity() {

    private lateinit var tvGoalId: TextView
    private lateinit var tvGoalName: TextView
    private lateinit var tvGoalAmount: TextView
    private lateinit var tvGoalSaved: TextView
    private lateinit var tvGoalDate: TextView
    private lateinit var tvGoalNote: TextView
    private lateinit var updateBtn: Button
    private lateinit var deleteBtn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_goal_details)

        initView()
        setValuesToViews()

        // UPDATE
        updateBtn.setOnClickListener {
            openUpdateDialog(
                intent.getStringExtra("goalId").toString(),
                intent.getStringExtra("goalName").toString(),
                intent.getStringExtra("goalAmount").toString(),
                intent.getStringExtra("goalSaved").toString(),
                intent.getStringExtra("goalDate").toString(),
                intent.getStringExtra("goalNote").toString(),
            )
        }

        // DELETE
        deleteBtn.setOnClickListener {
            deleteRecord(
                intent.getStringExtra("goalId").toString()
            )
        }
    }

    // DELETE
    private fun deleteRecord(
        id: String
    ){
        val dbRef = FirebaseDatabase.getInstance().getReference("Goals").child(id)
        val mTask = dbRef.removeValue()

        mTask.addOnSuccessListener {
            Toast.makeText(this, "Goal has been deleted", Toast.LENGTH_LONG).show()
            val intent = Intent(this, DisplayGoalsActivity::class.java)
            finish()
            startActivity(intent)
        }.addOnFailureListener{ error ->
            Toast.makeText(this, "Deleting Err ${error.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun initView() {
        TODO("Not yet implemented")
    }

    // FETCH
    private fun setValuesToViews(){

        tvGoalId.text = intent.getStringExtra("goalId")
        tvGoalName.text = intent.getStringExtra("goalName")
        tvGoalAmount.text = intent.getStringExtra("goalAmount")
        tvGoalSaved.text = intent.getStringExtra("goalSaved")
        tvGoalDate.text = intent.getStringExtra("goalDate")
        tvGoalNote.text = intent.getStringExtra("goalNote")

    }

    // UPDATE
    private fun openUpdateDialog(
        goalId: String,
        goalName: String,
        goalAmount: String,
        goalSaved: String,
        goalDate: String,
        goalNote: String
    ){
        val mDialog = AlertDialog.Builder(this)
        val inflater = layoutInflater
        val mDialogView = inflater.inflate(R.layout.activity_edit_goal, null)

        mDialog.setView(mDialogView)

        val etGoalName = mDialogView.findViewById<EditText>(R.id.edtName)
        val etGoalAmount = mDialogView.findViewById<EditText>(R.id.edtAmount)
        val etGoalSaved = mDialogView.findViewById<EditText>(R.id.edtSaved)
        val etGoalDate = mDialogView.findViewById<EditText>(R.id.edtDate)
        val etGoalNote = mDialogView.findViewById<EditText>(R.id.edtNote)
        val updateBtn = mDialogView.findViewById<TextView>(R.id.updateBtn)

        etGoalName.setText(intent.getStringExtra("goalName").toString())
        etGoalAmount.setText(intent.getStringExtra("goalAmount").toString())
        etGoalSaved.setText(intent.getStringExtra("goalSaved").toString())
        etGoalDate.setText(intent.getStringExtra("goalDate").toString())
        etGoalNote.setText(intent.getStringExtra("goalNote").toString())

        mDialog.setTitle("Updating $goalName Record")

        val alertDialog = mDialog.create()
        alertDialog.show()

        updateBtn.setOnClickListener {
            updateGoalData(
                goalId,
                etGoalName.text.toString(),
                etGoalAmount.text.toString(),
                etGoalSaved.text.toString(),
                etGoalDate.text.toString(),
                etGoalNote.text.toString(),

            )

            Toast.makeText(applicationContext, "Goal Data Updated!", Toast.LENGTH_LONG).show()

            // setting updating data to text views
            tvGoalName.text = etGoalName.text.toString()
            tvGoalAmount.text = etGoalAmount.text.toString()
            tvGoalSaved.text = etGoalSaved.text.toString()
            tvGoalDate.text = etGoalDate.text.toString()
            tvGoalNote.text = etGoalNote.text.toString()

            alertDialog.dismiss()
        }

    }

    private fun updateGoalData(
        id: String,
        name: String,
        amount: String,
        saved: String,
        date: String,
        note: String
    ){
        val dbRef = FirebaseDatabase.getInstance().getReference("Goals").child(id)
        val goalInfo = GoalModel(id, name, amount, saved, date, note)
        dbRef.setValue(goalInfo)
    }
}