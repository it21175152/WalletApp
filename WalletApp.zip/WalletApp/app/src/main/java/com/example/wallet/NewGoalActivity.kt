package com.example.wallet

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.example.models.GoalModel
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import java.lang.ref.Reference

class NewGoalActivity : AppCompatActivity() {

    private lateinit var edtName: EditText
    private lateinit var edtAmount: EditText
    private lateinit var edtSaved: EditText
    private lateinit var edtDate: EditText
    private lateinit var edtNote: EditText
    private lateinit var addBtn: TextView

    private lateinit var dbRef: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_new_goal)

        edtName = findViewById(R.id.edtName)
        edtAmount = findViewById(R.id.edtAmount)
        edtSaved = findViewById(R.id.edtSaved)
        edtDate = findViewById(R.id.edtDate)
        edtNote = findViewById(R.id.edtNote)
        addBtn = findViewById(R.id.addBtn)

        dbRef = FirebaseDatabase.getInstance().getReference("Goals")

        addBtn.setOnClickListener {
            saveGoalData()
        }
    }

    private fun saveGoalData() {
        //getting values
        val edtName = edtName.text.toString()
        val edtAmount = edtAmount.text.toString()
        val edtSaved = edtSaved.text.toString()
        val edtDate = edtDate.text.toString()
        val edtNote = edtNote.text.toString()

        if(edtName.isEmpty()){
            //edtName.error ="Please enter goal name"
        }

        if(edtAmount.isEmpty()){
            //edtAmount.error ="Please enter amount"
        }

        if(edtDate.isEmpty()){
            //edtDate.error ="Please enter goal date"
        }

        val goalId = dbRef.push().key!!

        val goal = GoalModel(goalId, edtName, edtAmount, edtSaved, edtDate, edtNote)

        dbRef.child(goalId).setValue(goal)
            .addOnCompleteListener {
                Toast.makeText(this, "Data inserted successfully!", Toast.LENGTH_LONG).show()

//                edtName.text.clear()
//                edtAmount.text.clear()
//                edtSaved.text.clear()
//                edtDate.text.clear()
//                edtNote.text.clear()

            }.addOnFailureListener {
                err -> Toast.makeText(this, "Error ${err.message}", Toast.LENGTH_LONG).show()
            }

    }
}