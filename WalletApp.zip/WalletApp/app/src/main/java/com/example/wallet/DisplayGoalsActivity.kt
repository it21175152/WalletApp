package com.example.wallet

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.adapters.GoalAdapter
import com.example.models.GoalModel
import com.google.firebase.database.*

class DisplayGoalsActivity : AppCompatActivity() {

    private lateinit var addIcon: ImageView
    private lateinit var goalRecyclerView: RecyclerView
    private lateinit var goalList: ArrayList<GoalModel>
    private lateinit var dbRef: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_display_goals)

        addIcon = findViewById(R.id.addIcon)

        addIcon.setOnClickListener {
            val intent = Intent(this, NewGoalActivity::class.java)
            startActivity(intent)
        }

        goalRecyclerView = findViewById(R.id.rvGoals)
        goalRecyclerView.layoutManager = LinearLayoutManager(this)
        goalRecyclerView.setHasFixedSize(true)

        goalList = arrayListOf<GoalModel>()

        getGoalsData()

    }

    // FETCH
    private fun getGoalsData() {
        //goalRecyclerView.visibility = View.GONE

        dbRef = FirebaseDatabase.getInstance().getReference("Goals")

        dbRef.addValueEventListener(object : ValueEventListener{
            override fun onDataChange(snapshot: DataSnapshot) {
                goalList.clear()
                if(snapshot.exists()){
                    for(goalSnap in snapshot.children){
                        val goalData = goalSnap.getValue(GoalModel::class.java)
                        goalList.add(goalData!!)
                    }
                    val mAdapter = GoalAdapter(goalList)
                    goalRecyclerView.adapter = mAdapter

                    mAdapter.setOnItemClickListener(object : GoalAdapter.onItemClickListener{
                        override fun onItemClick(position: Int) {
                            val intent = Intent(this@DisplayGoalsActivity, GoalDetailsActivity::class.java)

                            //put extra data here
                            intent.putExtra("goalId", goalList[position].goalId)
                            intent.putExtra("goalName", goalList[position].goalName)
                            intent.putExtra("goalAmount", goalList[position].goalAmount)
                            intent.putExtra("goalSaved", goalList[position].goalSaved)
                            intent.putExtra("goalDate", goalList[position].goalDate)
                            intent.putExtra("goalNote", goalList[position].goalNote)
                            startActivity(intent)
                        }

                    })
                }
            }

            override fun onCancelled(error: DatabaseError) {
                TODO("Not yet implemented")
            }

        })

    }
}