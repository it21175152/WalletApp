package com.example.test

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {

    private lateinit var btnCreateBudget: Button
    private lateinit var btnDisplayBudget: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnCreateBudget = findViewById(R.id.btnInsertBudget)
        btnDisplayBudget = findViewById(R.id.btnDisplayBudget)

        btnCreateBudget.setOnClickListener{
            val insert = Intent(this, CreateBudget::class.java)
            startActivity(insert)
        }

        btnDisplayBudget.setOnClickListener{
            val fetch = Intent(this, DisplayBudget::class.java)
            startActivity(fetch)
        }
    }
}