package com.example.test.models

import java.time.Period
import java.time.temporal.TemporalAmount

data class BudgetModel (
    var budgetId: String? = null,
    var name: String? = null,
    var period: String? = null,
    var amount: String? = null,
    var category: String? = null
)