package com.example.test

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.example.test.models.BudgetModel
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class CreateBudget : AppCompatActivity() {

    private lateinit var edtBudgetName: EditText
    private lateinit var edtBudgetPeriod: EditText
    private lateinit var edtBudgetAmount: EditText
    private lateinit var edtBudgetCategory: EditText
    private lateinit var btnAdd: Button

    private lateinit var database: DatabaseReference

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_budget)

        edtBudgetName = findViewById(R.id.edtName)
        edtBudgetPeriod = findViewById(R.id.edtPeriod)
        edtBudgetAmount = findViewById(R.id.edtAmount)
        edtBudgetCategory = findViewById(R.id.edtCategory)
        btnAdd = findViewById(R.id.btnAdd)

        database = FirebaseDatabase.getInstance().getReference("Budget")

        btnAdd.setOnClickListener{
            saveBudgetData()
        }
    }

    private fun saveBudgetData(){
        // Getting Values
        val name = edtBudgetName.text.toString()
        val period = edtBudgetPeriod.text.toString()
        val amount = edtBudgetAmount.text.toString()
        val category = edtBudgetCategory.text.toString()

        if(name.isEmpty()){
            edtBudgetName.error = "Please Enter the Name"
        }
        if(period.isEmpty()){
            edtBudgetPeriod.error = "Please Enter the Period"
        }
        if(amount.isEmpty()){
            edtBudgetAmount.error = "Please Enter the Amount"
        }
        if(category.isEmpty()){
            edtBudgetCategory.error = "Please Enter the Category"
        }

        // Create Unique Id
        val budgetId = database.push().key!!

        val budget = BudgetModel(budgetId,name, period, amount, category)

        database.child(budgetId).setValue(budget).addOnCompleteListener{
            Toast.makeText(this, "Budget Added Successfully", Toast.LENGTH_LONG).show()

            edtBudgetName.text.clear()
            edtBudgetPeriod.text.clear()
            edtBudgetAmount.text.clear()
            edtBudgetCategory.text.clear()

        }.addOnFailureListener {err ->
            Toast.makeText(this, "Error ${err.message}", Toast.LENGTH_LONG).show()
        }
    }
}